/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import static loginpage.FXMLDocumentController.name;

/**
 * FXML Controller class
 *
 * @author amzad
 */
public class SemesterController implements Initializable {
    FXMLDocumentController obj = new FXMLDocumentController();
    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    //localhost or IP, port, SID 
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";

    private static final String DB_USER = "std";
    private static final String DB_PASSWORD = "123";

    @FXML
    private JFXTextField tfsno;
    @FXML
    private JFXTextField tfsname;
    @FXML
    private JFXTextField tfstcredit;
    @FXML
    private JFXTextField tfslc;
    @FXML
    private JFXTextField tfstc;
    
    @FXML
     private void Exit(ActionEvent event)
     {
         System.exit(0);
     }
    @FXML
     private void Homebutton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Home.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void submitbutton(ActionEvent event) {
        Connection dbConnection = null;
        Statement statement = null;
        String A,B,C,D,E;
        A=tfsno.getText();
        B=tfsname.getText();
        C=tfstcredit.getText();
        D=tfslc.getText();
        E=tfstc.getText();
        
         String queryCOUR ="UPDATE SEMESTER SET SEMESTER_NO = '" + A + "',SEMESTER_NAME='" + B + "',TOTAL_CREDIT='" + C + "',LAB_CREDIT='"+D+"',THEORY_CREDIT='"+E+"' WHERE STUDENT_NAME = '" + name + "' "; 

        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            System.out.println(queryCOUR);
            statement.executeUpdate(queryCOUR);
           
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        } 
    }
    private static Connection getDBConnection() {

        Connection dbConnection = null;

        try {

            Class.forName(DB_DRIVER);

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        return dbConnection;
    
}  
    
}
