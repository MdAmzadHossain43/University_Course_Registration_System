/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
//import static loginpage.FXMLDocumentController.mail;
import static loginpage.FXMLDocumentController.name;

/**
 * FXML Controller class
 *
 * @author amzad
 */
public class InstructorController implements Initializable {
    FXMLDocumentController obj = new FXMLDocumentController();
    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    //localhost or IP, port, SID 
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";

    private static final String DB_USER = "std";
    private static final String DB_PASSWORD = "123";

    @FXML
    private JFXTextField insnametf;
    @FXML
    private JFXTextField insroomtf;
    @FXML
    private JFXTextField inscontf;
    @FXML
    private JFXTextField insmailtf;
    
    @FXML
     private void Exit(ActionEvent event)
     {
         System.exit(0);
     }
    @FXML
     private void Homebutton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Home.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
                 Connection dbConnection = null;
                 Statement statement = null;
                 dbConnect db = new dbConnect();
       
                    
        // TODO
    }    

    @FXML
    private void submitbutton(ActionEvent event) {
        Connection dbConnection = null;
        Statement statement = null;
        String A,B,C,D;
        A=insnametf.getText();
        B=insroomtf.getText();
        C=inscontf.getText();
        D=insmailtf.getText();
        //String queryINS ="INSERT INTO INSTRUCTOR" + "(INSTRUCTOR_NAME,INSTRUCTOR_ROOM,INSTRUCTOR_CONTACT,INSTRUCTOR_EMAIL)"+"VALUES('"+A+"','"+B+"','"+C+"','"+D+"')";
         String queryINS ="UPDATE INSTRUCTOR SET INSTRUCTOR_NAME = '" + A + "',INSTRUCTOR_ROOM='" + B + "',INSTRUCTOR_CONTACT='" + C + "',INSTRUCTOR_EMAIL='"+D+"' WHERE STUDENT_NAME = '" + name + "' "; 

        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            System.out.println(queryINS);
            statement.executeUpdate(queryINS);
           
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
        } 
    }
    private static Connection getDBConnection() {

        Connection dbConnection = null;

        try {

            Class.forName(DB_DRIVER);

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        return dbConnection;
    
}   
}
