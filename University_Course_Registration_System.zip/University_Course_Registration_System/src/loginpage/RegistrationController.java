/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

//import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
//import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
//import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author amzad
 */
public class RegistrationController implements Initializable {
    
    private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    //localhost or IP, port, SID 
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";

    private static final String DB_USER = "std";
    private static final String DB_PASSWORD = "123";
    @FXML
    private CheckBox cb2;
    @FXML
    private Label reglable;

    @FXML
     private void Exit(ActionEvent event)
     {
         System.exit(0);
     }
    /**
     * Initializes the controller class.
     */
    //@FXML
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
    @FXML
     private void signINbutton(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
    @FXML
    public Label label;
    public TextField tf1;
    public TextField tf2;
    public TextField tf3;
    public TextField tf4;
    public TextField tf5;
    public CheckBox cb1;
    public DatePicker dp;
    public Label textLable;

    @FXML
    public void submitbutton(ActionEvent event) throws SQLException,IOException  {
        Connection dbConnection = null;
        Statement statement = null;

  
        String C=tf3.getText();
      
        String D=tf4.getText();
        
        String E=tf5.getText();
        String F = cb1.getText();
        String date = dp.getValue().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
               
                String querySQL = "INSERT INTO REGISTRATION"
                + "(STUDENT_NAME,EMAIL_ID,STD_PASSWORD,STD_GENDER,DATE_OF_BIRTH)"
                + "VALUES('"+C+"', '"+D+"', '"+E+"' , '"+F+"', '"+date+"')";
                String querySTU = "INSERT INTO STUDENT"
                + "(STUDENT_NAME,STUDENT_EMAIL)"
                + "VALUES('"+C+"', '"+D+"')";
               

        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            System.out.println(querySQL);
            statement.executeUpdate(querySQL);
            statement.executeUpdate(querySTU);
           
            
            
            
            reglable.setText("REGISTRATION SUCCESSFUL");
        } 
        catch (SQLException e) {
            System.out.println(e.getMessage());
            reglable.setText("REGISTRATION failed");
        } 
        finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }

        }

    }

    private static Connection getDBConnection() {

        Connection dbConnection = null;

        try {

            Class.forName(DB_DRIVER);

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        return dbConnection;
    }

  

        
    }
    

