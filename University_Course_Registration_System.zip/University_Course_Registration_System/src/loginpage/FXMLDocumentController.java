/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 *
 * @author amzad
 */
public class FXMLDocumentController implements Initializable {
     public static String name,mail,pass;
     private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    //localhost or IP, port, SID 
    private static final String DB_CONNECTION = "jdbc:oracle:thin:@localhost:1521:orcl";

    private static final String DB_USER = "std";
    private static final String DB_PASSWORD = "123";
    
    @FXML
    private Label label;
    @FXML
    private JFXTextField usertf;
    @FXML
    private JFXPasswordField passwordtf;
    @FXML
    private Label txtlable;
    
    @FXML
    private void Homebutton(ActionEvent event) throws IOException
    {
       
        Connection dbConnection = null;
        Statement statement = null;
        dbConnect db = new dbConnect();
        Connection Conn = db.getConn();
        
        System.out.println("CONNECTION ESTABLISHED");
            String A=usertf.getText();
            
            String B=passwordtf.getText();
            int log=1;
        try {
            
            String querySQL ="select EMAIL_ID,STUDENT_NAME,STD_PASSWORD from REGISTRATION WHERE  STUDENT_NAME = '"+A+"' and STD_PASSWORD = '"+B+"' "; 
            System.out.println(querySQL);
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
             ResultSet rs = statement.executeQuery(querySQL);
            
            while(rs.next()){
                if (rs.getString(2).equals(A) && rs.getString(3).equals(B)) {
                    mail=rs.getString(1);
                    name=rs.getString(2);
                    pass=rs.getString(3);
                    
                    log = 0;
                }
                else
                {
                    log=1;
                }
              }  
                if (log == 0) {
                    Parent tableViewParent = FXMLLoader.load(getClass().getResource("Home.fxml"));
                    Scene tableViewScene = new Scene(tableViewParent);

                    Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

                    window.setScene(tableViewScene);
                    window.show();
                } else if (log == 1) {
                    txtlable.setText("LOGIN FAILED");
                }
            
        }
        catch (SQLException e) {
            System.out.println(e.getMessage());
        } 
    }
    @FXML
    private void Exit(ActionEvent event)
     {
         System.exit(0);
     }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
    
    @FXML
      private void ButtonPushed(ActionEvent event) throws IOException
    {
        Parent regParent = FXMLLoader.load(getClass().getResource("Registration.fxml"));
        Scene regScene = new Scene(regParent);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(regScene);
        window.show();
    }
      private static Connection getDBConnection() {

        Connection dbConnection = null;

        try {

            Class.forName(DB_DRIVER);

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            dbConnection = DriverManager.getConnection(
                    DB_CONNECTION, DB_USER, DB_PASSWORD);
            return dbConnection;

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }
        return dbConnection;
    
}
    
}
